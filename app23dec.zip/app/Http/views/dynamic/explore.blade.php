<div id="help" class="explore_list">
<?php use App\Http\Controllers\Action_controllers;
      use App\Http\Models\Product_category;
      use App\Http\Models\Category_model;
      ?>
<div class="main text-left">
    <h3 class="wow" data-wow-duration="2s" data-wow-delay="0.2s"> Discover / All Categories</h3>
</div>


        @if($ProductCategoryRecordCount>0 )
            @foreach($qGetProductResult as $resultProduct)
                <?php 
                        $datetime1 = strtotime($resultProduct->productDate);
                        $datetime2 = time(); // or your date as well
                        //$datetime2 = strtotime($resultProduct->productExpiredDate);
                        $datediff = $datetime1-$datetime2;
                        $interval=floor($datediff / (60 * 60 * 24));
                        $interval=$interval+1;

                        $data_category=Product_category::where('productID',$resultProduct->productID)->select('categoryID')->first();

                        $category_name=Category_model::where('categoryID',$data_category['categoryID'])->select('categoryname')->first();
                ?>
               
                    <div class="children {{$resultProduct->categoryName}}">
                      <a href="{{url('/event')}}/{{$resultProduct->url_title}}">
                        <div class="help_block phelp_block">
                            <div class="image-base">
                                <div class="baronNeueBlack" style="position: relative; ">
                                    <div class="corner-date-background"></div>
                                    <div class="deadline-month">{{date("M", strtotime($resultProduct->productDate))}}.</div>
                                    <div class="deadline-day">{{date("d", strtotime($resultProduct->productDate))}}</div>
                                </div>
                                
                                      <div class="events_images">
                                               @if(file_exists(public_path().'/upload/product/mainimages/'.$resultProduct->prodcutImage) && strlen($resultProduct->prodcutImage) > 0)
                                                    <img src="{{url('/')}}/upload/product/mainimages/{{$resultProduct->prodcutImage}}" alt="" title="" style="width:345px;"/>
                                                @else
                                                    <img src="{!! url('components/front-end/images/no-images.png') !!}" alt="" title="" />
                                                @endif
                                            </div>
                                
                                <div class="help-info" >
                                    <h3 style="float:right">@if($interval==0) Today @else {{$interval}} days until event @endif</h3>
                                    <h3 class="project-header-title">{{$resultProduct->productName}}  <span style="color: #ffc34d;"> @if(!empty($category_name->categoryname))({{$category_name->categoryname}}) @endif</span></h3>
                                    <h5 class="project-header-tagline">
                                                <br>
                                                <br>
                                                <div style="padding-top: 25px;">
                                                   
                                                        <i class="fa fa-clock-o" aria-hidden="true"></i> {{ date("g:i a", strtotime($resultProduct->event_time)) }}
                                                   
                                                </div>
                                            </h5>
                                    <h5 class="project-header-tagline"><?php /*?>Tagline inserted here<?php */?>
                                        <br>
                                        <br>
                                        <div>
                                            <span class="gm-marker">&nbsp</span>
                                            <span>{{$resultProduct->city}}</span>
                                        </div>
                                    </h5>
                                    <?php $data=Action_controllers::getProductorderTotalCount($resultProduct->productID); 
                                         
                                    ?>
                                     <?php
                                        $goalpr=number_format($data['goalper'],2);
                                            if($goalpr>100)
                                                { $goalpr=100; }

                                            ?>
                                    <div class="box-bottom">
                                        <div class="skillbar" data-percent="{{ $goalpr }}%">
                                            <div class="skillbar-bar" style="width: {{  $goalpr }}%;"></div>
                                            <div class="skill-bar-percent" style="left: {{  $goalpr }}%;">{{  number_format($data['goalper'],2) }}%</div>
                                        </div>
                                        <p class="pull-left text-left">Raised<br><span>${{number_format($data['raised'],2)}}</span></p>
                                        <p class="pull-right text-right pright_info">goal<br><span>${{number_format($resultProduct->price,2)}}</span></p>
                                    </div>
                                </div>
                                <div class="helpbox-overlay">
                                    <div class="help-btn-base">
                                        <form class="donation-form" action="{{url('/event')}}/{{$resultProduct->url_title}}" method="get" target="_top">
                                            <button type="submit"> 
                                            Donate
                                            </button>                    
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a></div>
                
            @endforeach
        @else
            <div>Record not found!</div>
        @endif
            <nav class="pagination col-md-12">
                <ul class="pagination__list">
                    <li>@include('include.pagination', ['paginator' => $qGetProductResult])</li>
                </ul>
            </nav>
        
        <?php /*?><div class="col-sm-12">
            <div class="col-sm-5 col-sm-offset-4">
                <a class="btn btn-default hvr-shutter-out-horizontal" href="#">Show More Projects</a>
            </div>
        </div><?php */?>
</div>