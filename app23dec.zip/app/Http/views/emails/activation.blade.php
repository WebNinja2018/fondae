please activate your account following link.
<a href="{{ route('auth.activate',$token) }}"> {{ route('auth.activate',$token) }}</a>