

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Contact us form data Received</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

<h3>Contact us form data </h3>

<h4>Name: {{ $name}}</h4>
<h4>Email: {{ $email }} </h4>
<h4>Message: {{ $bodyMessage }}</h4>

</body>
</html>