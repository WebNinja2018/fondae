

The project owner has received your donation for " {{$event_name}} " successfully. 
Thank you for supporting.